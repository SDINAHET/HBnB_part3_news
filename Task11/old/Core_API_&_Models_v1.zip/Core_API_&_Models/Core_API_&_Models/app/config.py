# Configuration file for Flask environments.import os

class Config:
    """
    Configuration de base.
    """
    SECRET_KEY = os.environ.get('SECRET_KEY', 'default_secret_key')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JSONIFY_PRETTYPRINT_REGULAR = True
    CORS_HEADERS = 'Content-Type'

class DevelopmentConfig(Config):
    """
    Configuration pour le développement.
    """
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'DEV_DATABASE_URI',
        'sqlite:///development.db'
    )

class TestingConfig(Config):
    """
    Configuration pour les tests.
    """
    TESTING = True
    SQLALCHEMY_DATABASE_URI = os.environ.get(
        'TEST_DATABASE_URI',
        'sqlite:///test.db'
    )
    WTF_CSRF_ENABLED = False  # Désactiver CSRF pour faciliter les tests

class ProductionConfig(Config):
    """
    Configuration pour la production.
    """
    DEBUG = False
    SQLALCHEMY_DATABASE_URI = os.environ.get('PROD_DATABASE_URI')

# Mapping des configurations
config = {
    "development": DevelopmentConfig,
    "testing": TestingConfig,
    "production": ProductionConfig,
    "default": DevelopmentConfig
}
